<?php
include('./db_conn.php');
header("Content-Type: text/html; charset=UTF-8");

$id = $_POST['id'];
$passwd = $_POST['passwd'];
$name = $_POST['name'];
$mac = $_POST['mac'];

$query = "insert into student_info VALUES (".$id.",'".$name."',PASSWORD(".$passwd."),'".$mac."','0')";
$re = mysql_query($query);
if($re){
	$query = "insert into chul_check(student_number,student_name,mac_address) values(".$id.",'".$name."','".$mac."')";
	mysql_query($query);
	echo "0";
}
else{echo "1";}
mysql_close();
?>