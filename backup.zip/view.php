<?php
include('./db_conn.php');
session_start();
$id = $_GET['id'];
$s_id = $_SESSION['id'];
$s_lv = $_SESSION['level'];
$s_name = $_SESSION['name'];
if($id != $s_id){
	session_destroy();
	echo "<script type='text/javascript'>";
	echo "location.replace('./welcome.php');";
	echo "</script>";
}
if($s_lv == 1){
	echo "<script type='text/javascript'>";
	//echo "location.replace('./admin_view.php');";
	echo "location.replace('./admin.html');";
	echo "</script>";
}
echo "<meta charset='UTF-8'>";

echo "<LINK href='../css/style.css' rel='stylesheet' type='text/css'>";

echo "<script type='text/javascript'>\n";
echo "function logout(){ \n\tlocation.replace('./welcome.php');\n}\n";
echo "</script>";

echo "<table class='chul'>";
echo "<caption>".$s_name."님 출석 현황</caption>";
echo "<thead><tr><th id='name'>과목</th><th id='semi'>수업 시작</th><th id='semi'>중간 결과</th><th id='final'>출석 결과</th></thead><tfoot>";
$query = "select chul.first_check, chul.semi_check, chul.final_check, lec.lecture_1, lec.lecture_2, lec.lecture_3, lec.lecture_4, lec.lecture_5, lec.lecture_6 from chul_check as chul, student_info as lec where chul.student_number ='".$id."' limit 1";
$result = mysql_query($query);
while($row = @mysql_fetch_array($result)){
	echo "<th>".$row[lecture_1]."</th>";
	switch ($row[first_check]){
		case 0: $first_check = "미체크";break;
		case 1: $first_check = "체크";
	}
	switch ($row[semi_check]){
		case 0: $semi_check = "미체크";break;
		case 1: $semi_check = "체크";
	}
	switch ($row[final_check]){
		case 0: $final_check = "결석";break;
		case 1: $final_check = "출석";
	}
	echo "<td>".$first_check."</td>";
	echo "<td>".$semi_check."</td>";
	echo "<td>".$final_check."</td></tr>";
	
	echo "<th>".$row[lecture_2]."</th>";
	switch ($row[first_check]){
		case 0: $first_check = "미체크";break;
		case 1: $first_check = "체크";
	}
	switch ($row[semi_check]){
		case 0: $semi_check = "미체크";break;
		case 1: $semi_check = "체크";
	}
	switch ($row[final_check]){
		case 0: $final_check = "결석";break;
		case 1: $final_check = "출석";
	}
	echo "<td>".$first_check."</td>";
	echo "<td>".$semi_check."</td>";
	echo "<td>".$final_check."</td></tr>";
	
	echo "<th>".$row[lecture_3]."</th>";
	switch ($row[first_check]){
		case 0: $first_check = "미체크";break;
		case 1: $first_check = "체크";
	}
	switch ($row[semi_check]){
		case 0: $semi_check = "미체크";break;
		case 1: $semi_check = "체크";
	}
	switch ($row[final_check]){
		case 0: $final_check = "결석";break;
		case 1: $final_check = "출석";
	}
	echo "<td>".$first_check."</td>";
	echo "<td>".$semi_check."</td>";
	echo "<td>".$final_check."</td></tr>";
	
	echo "<th>".$row[lecture_4]."</th>";
	switch ($row[first_check]){
		case 0: $first_check = "미체크";break;
		case 1: $first_check = "체크";
	}
	switch ($row[semi_check]){
		case 0: $semi_check = "미체크";break;
		case 1: $semi_check = "체크";
	}
	switch ($row[final_check]){
		case 0: $final_check = "결석";break;
		case 1: $final_check = "출석";
	}
	echo "<td>".$first_check."</td>";
	echo "<td>".$semi_check."</td>";
	echo "<td>".$final_check."</td></tr>";
	
	echo "<th>".$row[lecture_5]."</th>";
	switch ($row[first_check]){
		case 0: $first_check = "미체크";break;
		case 1: $first_check = "체크";
	}
	switch ($row[semi_check]){
		case 0: $semi_check = "미체크";break;
		case 1: $semi_check = "체크";
	}
	switch ($row[final_check]){
		case 0: $final_check = "결석";break;
		case 1: $final_check = "출석";
	}
	echo "<td>".$first_check."</td>";
	echo "<td>".$semi_check."</td>";
	echo "<td>".$final_check."</td></tr>";
	
	echo "<th>".$row[lecture_6]."</th>";
	switch ($row[first_check]){
		case 0: $first_check = "미체크";break;
		case 1: $first_check = "체크";
	}
	switch ($row[semi_check]){
		case 0: $semi_check = "미체크";break;
		case 1: $semi_check = "체크";
	}
	switch ($row[final_check]){
		case 0: $final_check = "결석";break;
		case 1: $final_check = "출석";
	}
	echo "<td>".$first_check."</td>";
	echo "<td>".$semi_check."</td>";
	echo "<td>".$final_check."</td></tr></tfoot>";
}
mysql_close();
echo "</table>";
echo "<center><input type='button' class='btn' name='logout' id='logout' value='logout' onclick='logout()'/></center>";
?>