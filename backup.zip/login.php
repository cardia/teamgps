<?
include('./db_conn.php');

$id = $_POST['id'];
$passwd = $_POST['passwd'];

$query = "select count(*) from student_info where student_number='".$id."' and password = PASSWORD('".$passwd."')";
$re = mysql_query($query);
$result = mysql_result($re,0);
if($result == 0){
	session_start();
	$_SESSION['id']=$id;
	$query = "select student_name,level from student_info where student_number='".$id."'";
	$result = mysql_query($query);
	while($row = @mysql_fetch_array($result)){
		$_SESSION['name'] = $row[student_name];
		$_SESSION['level'] = $row[level];
	}
	echo "0";
}
else{
	echo "1";
}
mysql_close();
?>