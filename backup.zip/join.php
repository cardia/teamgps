<?php
header("Content-Type: text/html; charset=UTF-8");

	$ip=getenv("REMOTE_ADDR");
	if(PHP_OS=='WINNT'){
		exec("arp -a", $rgResult);
        $mac_template="/[\d|A-F]{2}\-[\d|A-F]{2}\-[\d|A-F]{2}\-[\d|A-F]{2}\-[\d|A-F]{2}\-[\d|A-F]{2}/i"; 
        foreach($rgResult as $key=>$value){ 
            if(strpos($value, $ip)!==FALSE){ 
                preg_match($mac_template, $value, $matches);
                break; 
            } 
        } 
    } else{ 
        exec("arp -a | grep $ip", $rgResult); 
        $mac_template="/[\d|A-F]{2}\:[\d|A-F]{2}\:[\d|A-F]{2}\:[\d|A-F]{2}\:[\d|A-F]{2}\:[\d|A-F]{2}/i"; 
        preg_match($mac_template, $rgResult[0], $matches); 
    } 
    $mac=$matches[0];
?>
<html>
<head>
<meta charset="UTF-8">
<script type="text/javascript" src="../js/jquery-2.1.3.min.js"></script>
<script type="text/javascript">
function pre_sign(){
	if($('input:checked').val() == "1"){
		alert("수집에 동의 바랍니다");
		return false;
	}
	if($('#sn').val() == ""){
		alert("학번을 입력 바랍니다");
		return false;
	}
	if($('#password').val() == ""){
		alert("비밀번호를 입력 바랍니다");
		return false;
	}
	if($('#name').val() == ""){
		alert("이름을 입력 바랍니다");
		return false;
	}
	
	$.ajax({
		type: "POST",
		url: "submit.php",
		data: "id="+$('#sn').val()+"&passwd="+$('#password').val()+"&name="+$('#name').val()+"&mac="+$('#mac').val(),
		cache: false,
		success: function(data){
			if(data == 0){
				alert("회원가입 되었습니다");
				location.replace("./welcome.php");
			}
			else{
				alert("서버 오류로 가입에 실패 하였습니다\n 잠시후 다시 시도 바랍니다");
			}				
		}
	});
}
function dsn(sn){
	var id = sn.value;
	if(sn.value.length==8){
		$.ajax({
			type: "POST",
			url: "check_sn.php",
			data: "id="+ id ,
			cache: false,
			success: function(data){
				if(data == 0){
					alert("사용 가능한 학번 입니다");
				}
				else{
					alert("사용 중인 학번 입니다");
					$('#sn').val("");
				}				
			}
		});
	}
}
</script>
<title>가입</title>
</head>
<body>
<textarea rows="4" cols="30">출석 체크 및 출석 결과 확인을 위해 학번 및 맥주소 수집에 동의 하십니까?</textarea><br/>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="radio" id="radio_agree" value="0" checked/>동의
<input type="radio" name="radio" id="radio_deny" value="1"/>거절
<br/><p/>
<table>
	<tr>
		<td>학번</td>
		<td><input type="text" name="sn" id="sn" size="20" onkeyup="dsn(this)" required /></td>
	</tr>
	<tr>
		<td>비밀번호</td>
		<td><input type="password" name="password" id="password" size="20" required /></td>
	</tr>
	<tr>
		<td>이름</td>
		<td><input type="text" name="name" id="name" size="20" required /></td>
	</tr>
	<tr>
		<td>맥주소</td>
		<td><input type="text" name="mac" id="mac" size="20" value="<?=$mac?>" readonly required /></td>
	</tr>
</table>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" id="submit" onclick="pre_sign()" value="가입"/>
</body>
</html>