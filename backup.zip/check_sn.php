<?php
header("Content-Type: text/html; charset=UTF-8");
include('./db_conn.php');

$id = $_POST["id"];

$query = "select count(student_number) from student_info where student_number = '".$id."'";
$re = mysql_query($query);
$result = mysql_result($re,0);
if($result == 0){
	echo "0";
}
else{
	echo "1";
}
mysql_close($link);
?>